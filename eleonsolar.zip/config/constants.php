<?php
//LOCALHOST
define('WEB_URL', 'http://localhost/eleonsolar/');
//DOMAIN
//define('WEB_URL', 'http://eleonsolar.com/');
